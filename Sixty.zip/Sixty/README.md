# Sixty — sintetizador polifónico inspirado no Juno-60

Plugin VST3 (Windows, macOS, Linux), AU (macOS) e aplicação Standalone, feito com JUCE 8.

> O nome "Juno" é marca da Roland. Este projeto chama-se *Sixty* de propósito:
> se o for distribuir, não use o nome nem o logótipo do original.

## Arquitectura

| Bloco | Implementação |
|---|---|
| Vozes | 6 por defeito (Poly 1–16), com roubo de nota; unison de 1 a 4 osciladores por nota |
| DCO | serra + pulso (PWM manual ou por LFO) + sub-oscilador + ruído, PolyBLEP anti-aliasing |
| Range | 16' / 8' / 4' |
| HPF | 4 posições, global, 6 dB/oct: directo / ~235 Hz / ~520 Hz / ~1,1 kHz (calculado do esquema) |
| VCF | passa-baixo 24 dB/oct, 4 polos com saturação, ressonância até auto-oscilação, key follow, envelope bipolar, LFO |
| Envelope | ADSR exponencial (ENV) para VCF/PWM; VCA em modo Env, Gate ou Env2 (segundo ADSR) |
| LFO | triangular, global, 0,3–20 Hz (ou sync à DAW), com delay (0–1,5 s) → DCO, VCF; o PWM usa o LFO sem delay; mod wheel (CC1) com faders DCO/VCF |
| Chorus | I, II, I+II (BBD simulado por linha de atraso modulada, taps estéreo em oposição) |
| Extras | deriva do oscilador mestre (comum às vozes), sensibilidade à velocidade, sensibilidade do bender (0–7 st), PWM por envelope, teclado no ecrã |

## Inspirado no Jun-6 V (Arturia)

Funcionalidades acrescentadas depois de ler o manual do Jun-6 V:

- **Arpejador** (Up / Up&Dn / Down, 1–3 oitavas, 1,36–45 Hz ou sincronizado com o tempo da DAW), com **Hold**.
- **Modo de acordes** (Octave, Fifth, Sus4, Minor, Minor7/9/11, Major, Major7/9/11): uma tecla toca o acorde; combina com o arpejador.
- **LFO 1** com sync à DAW e dois modos de delay (Delay = silêncio e depois subida; Rise = subida imediata).
- **Painel Advanced** (botão no topo): matriz de modulação **Assign** (roda, velocity, aftertouch), **LFO 2** (seno, triângulo, serra, rampa, quadrada, S&H; retrigger Off/Mono/Poly; sync), **ENV 2** (também ligável ao VCA) e dois destinos para cada um (Pitch, PWM, Cutoff, Reson., Sub, Noise, Level), mais **Delay** (sync, feedback, dispersão estéreo) e **Reverb** (size, damp, decay, predelay).
- **Unison + detune**, **portamento** por tempo, bender com sensibilidade até 12 semitons e bender no filtro, faders de roda para DCO e VCF.
- **Voice calibration** Good / Avg / Poor: dispersão fixa por voz em cutoff, ressonância, nível, tempos de envelope e afinação.
- **Ruído do chorus** opcional; Delay e Reverb vêm ligados mas com Dry/Wet a 0 (como no Jun-6 V).
- Janela **redimensionável** (arraste o canto) mantendo a proporção.

Diferenças em relação ao Jun-6 V: 8 destinos de modulação em vez de 35, sem acordes personalizados, sem macros nem navegador de presets, e o delay do LFO e o resto das gamas seguem as Service Notes da Roland (o Jun-6 V alarga algumas, por exemplo decay até 19 s).

## Chorus

Três botões como no original: **OFF**, **I** e **II**. Carregar em I e II ao mesmo tempo dá o modo **I+II**, que (como descreve o manual do Jun-6 V)
deixa de ser estéreo: as duas linhas de atraso ficam no mesmo sentido, o sinal fica mono e o LFO é muito mais rápido, o que dá um vibrato.
I e II são estéreo (taps em oposição de fase). O botão NOISE junta o ruído da BBD.

## Presets

Na barra do topo: **<** e **>** passam ao preset anterior/seguinte, o nome abre a lista, e **SAVE** guarda.

- O nome mostra um **\*** quando algum parâmetro mudou desde o último load ou save.
- A lista tem 15 presets de fábrica (por exemplo Brass Section, Warm Strings, PWM Pad, Sub Bass, Arp Glass, Chord Stab) e os teus presets.
- **Save** sobrescreve o preset de utilizador atual; num preset de fábrica ou no Init pede um nome (**Save as...**).
- **Delete current**, **Import...** e **Export...** (ficheiros `.sixtypreset`, em XML) e **Open presets folder**.
- Os presets do utilizador ficam em `~/.config/Sixty/Presets` (Linux), `%APPDATA%\Sixty\Presets` (Windows) e
  `~/Library/Application Support/Sixty/Presets` (macOS). O nome do preset também fica guardado no projeto da DAW.

## Interface

Faixa única de controlos, por ordem do sinal (LFO, DCO, HPF, VCF, VCA, ENV, chorus, master), com cabeçalhos coloridos,
laterais de madeira, faders com tampa na cor da secção, botões de escolha em vez de menus, knobs para master e performance
(bender, roda, portamento, unison, poly, deriva, velocity) e teclado de 61 teclas. O botão ADVANCED abre o painel superior.

## Compilar

Precisa de CMake ≥ 3.22, Git e um compilador C++17. O JUCE é descarregado automaticamente
na primeira configuração.

### Windows
Visual Studio 2022 (carga de trabalho "Desktop development with C++") e CMake.
```
cmake -B build
cmake --build build --config Release
```

### macOS
Xcode (ou Command Line Tools) e CMake (`brew install cmake`). Gera binário universal (arm64 + x86_64).
```
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

### Linux (Debian/Ubuntu)
```
sudo apt install build-essential cmake git libasound2-dev libfreetype-dev libfontconfig1-dev \
  libx11-dev libxcomposite-dev libxcursor-dev libxext-dev libxinerama-dev libxrandr-dev \
  libxrender-dev libgl1-mesa-dev mesa-common-dev
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

Os binários ficam em `build/Sixty_artefacts/` (`VST3/`, `AU/`, `Standalone/`).
Para copiar logo para a pasta de plugins do sistema, adicione `-DCOPY_AFTER_BUILD=ON`
(no Windows precisa de um terminal com permissões de administrador).

O ficheiro `.github/workflows/build.yml` compila nos três sistemas no GitHub Actions e
publica os binários como artefactos, útil se só tiver acesso a uma das plataformas.

## Valores confirmados nas Service Notes do Juno-60

Lidos do PDF das Service Notes (1983):

- Envelope: ataque 1 ms–3 s, decay e release 2 ms–12 s. LFO: 0,3–20 Hz, delay até 1,5 s.
- Oscilador mestre (comum a todas as vozes): LFO até ±300 cents, bender até ±700 cents, tune ±50 cents.
  O DCO divide um único relógio mestre, por isso **não há desafinação independente por voz**; a deriva do modelo é global.
- LFO → filtro: 6 Vp-p, ou seja ±3 oitavas. Envelope → filtro: chega a ~30 kHz (≈ 9 oitavas). Key follow a 100% = tracking de 1 V/oit.
- A ressonância máxima é ajustada para auto-oscilar em seno de 4 Vp-p.
- Largura de pulso: 50% a 95%. O seletor de fonte do PWM tem LFO, manual e ENV.
- O HPF está na placa de chorus (mux 4051 a escolher C 22 nF / 10 nF / 4,7 nF, posição 0 directa), depois do mix das vozes e antes do chorus.
- Chorus: sinal directo somado a duas linhas BBD (MN3009) com clocks modulados em oposição; filtros de ~7 kHz antes e depois da BBD.
- LFO do chorus (anotado no esquema da Panel Board B): modo I = 20 Vpp com período de ~2 s, modo II = 20 Vpp com ~1,2 s,
  modo I+II = 1,6 Vpp, ou seja 0,08x a profundidade. As duas saídas do LFO estão em oposição de fase (L/R).
- Ordem do sinal (diagrama de blocos): VCF → VCA por voz → soma → HPF → VCA de nível → chorus → volume.
- Atribuição de vozes cíclica CH1–CH6, a 7.ª tecla rouba a primeira (igual ao roubo da voz mais antiga usado aqui).
- Afinação de fábrica nos procedimentos de ajuste: A4 = 442 Hz (o plugin usa 440 Hz, como a DAW).

### Ainda por verificar (inferências minhas)
- Chorus I e II: períodos de ~2 s e ~1,2 s lidos no esquema (0,513 e 0,863 Hz são valores mais precisos de memória, compatíveis).
  Modo I+II: a taxa de ~9,75 Hz é inferência (a anotação do período está ilegível no scan; amplitude 12,5x menor implica ~10x mais rápido).
  Os atrasos da BBD (centro 3,5 ms, ±1 ms) continuam de memória.
- Mapeamento do LFO no PWM (modelado como 50% → 50%+depth×45%).
- Forma exacta do delay do LFO (silêncio e depois rampa de 1/3 do tempo) e se re-dispara em cada tecla ou só na primeira.
- Curva do filtro: o modelo é um ladder genérico, não o IR3109 do original.
- Frequências do HPF dependem de a impedância de carga ser ~31 kΩ (470k ‖ 33k).

## Estrutura

```
Source/Dsp.h              envelope, filtro ladder, HPF, chorus, PolyBLEP
Source/Voice.h            voz (DCO -> VCF -> VCA)
Source/PluginProcessor.*  parâmetros, LFO, HPF, chorus, saída
Source/PluginEditor.*     interface
```

## Licença do JUCE
O JUCE é AGPLv3 ou comercial. Para distribuir o plugin sem abrir o código-fonte
precisa de uma licença JUCE comercial.

## Próximos passos
Presets, modo unison/mono com portamento, oversampling 2x no filtro, modelação mais fiel do
IR3109 e do ruído da BBD, redimensionamento da interface.
