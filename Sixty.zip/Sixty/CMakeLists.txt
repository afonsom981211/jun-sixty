cmake_minimum_required(VERSION 3.22)
project(Sixty VERSION 0.1.0)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# macOS: binario universal (Apple Silicon + Intel)
if(APPLE)
  set(CMAKE_OSX_ARCHITECTURES "arm64;x86_64" CACHE STRING "" FORCE)
  set(CMAKE_OSX_DEPLOYMENT_TARGET "10.13" CACHE STRING "" FORCE)
endif()

option(COPY_AFTER_BUILD "Copiar o plugin para a pasta de plugins do sistema" OFF)

include(FetchContent)
FetchContent_Declare(JUCE
  GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
  GIT_TAG        8.0.4
  GIT_SHALLOW    TRUE)
FetchContent_MakeAvailable(JUCE)

set(SIXTY_FORMATS VST3 Standalone)
if(APPLE)
  list(APPEND SIXTY_FORMATS AU)
endif()

juce_add_plugin(Sixty
  COMPANY_NAME "Atelier"
  PRODUCT_NAME "Sixty"
  IS_SYNTH TRUE
  NEEDS_MIDI_INPUT TRUE
  NEEDS_MIDI_OUTPUT FALSE
  IS_MIDI_EFFECT FALSE
  EDITOR_WANTS_KEYBOARD_FOCUS TRUE
  COPY_PLUGIN_AFTER_BUILD ${COPY_AFTER_BUILD}
  PLUGIN_MANUFACTURER_CODE Atlr
  PLUGIN_CODE Sxty
  FORMATS ${SIXTY_FORMATS}
  VST3_CATEGORIES Instrument Synth
  AU_MAIN_TYPE kAudioUnitType_MusicDevice)

target_sources(Sixty PRIVATE
  Source/PluginProcessor.cpp
  Source/PluginEditor.cpp)

target_compile_definitions(Sixty PUBLIC
  JUCE_WEB_BROWSER=0
  JUCE_USE_CURL=0
  JUCE_VST3_CAN_REPLACE_VST2=0)

target_link_libraries(Sixty
  PRIVATE
    juce::juce_audio_utils
  PUBLIC
    juce::juce_recommended_config_flags
    juce::juce_recommended_lto_flags
    juce::juce_recommended_warning_flags)
