#include "Presets.h"

namespace
{
using V = std::vector<std::pair<const char*, float>>;
struct Factory { const char* name; V values; };

// Valores "reais" dos parametros (indice para as escolhas, 0/1 para interruptores).
// Tudo o que nao esta listado volta ao valor por defeito.
const std::vector<Factory>& factoryPresets()
{
    static const std::vector<Factory> list = {
        { "Init", {} },

        { "Brass Section", { { "saw", 1.0f }, { "pulse", 0.0f }, { "sub", 0.2f }, { "cutoff", 1400.0f }, { "res", 0.1f },
                             { "envAmt", 0.5f }, { "keyFollow", 0.5f }, { "attack", 0.07f }, { "decay", 1.0f },
                             { "sustain", 0.7f }, { "release", 0.25f }, { "chorus", 1.0f }, { "lfoDco", 0.05f },
                             { "lfoDelay", 0.5f }, { "lfoRate", 5.0f } } },

        { "Warm Strings", { { "saw", 1.0f }, { "pulse", 1.0f }, { "pwMode", 1.0f }, { "pw", 0.6f }, { "lfoRate", 0.8f },
                            { "cutoff", 3500.0f }, { "res", 0.05f }, { "envAmt", 0.15f }, { "attack", 0.6f },
                            { "decay", 2.0f }, { "sustain", 0.85f }, { "release", 0.9f }, { "hpf", 1.0f },
                            { "chorus", 2.0f }, { "revMix", 0.2f } } },

        { "PWM Pad", { { "saw", 0.0f }, { "pulse", 1.0f }, { "pwMode", 1.0f }, { "pw", 0.8f }, { "lfoRate", 0.4f },
                       { "lfoDelay", 0.4f }, { "cutoff", 2200.0f }, { "res", 0.2f }, { "envAmt", 0.25f },
                       { "attack", 1.2f }, { "decay", 3.0f }, { "sustain", 0.7f }, { "release", 1.8f },
                       { "chorus", 2.0f }, { "delayMix", 0.15f }, { "revMix", 0.3f } } },

        { "Sub Bass", { { "range", 0.0f }, { "saw", 1.0f }, { "pulse", 0.0f }, { "sub", 0.7f }, { "cutoff", 400.0f },
                        { "res", 0.25f }, { "envAmt", 0.35f }, { "keyFollow", 0.3f }, { "attack", 0.001f },
                        { "decay", 0.35f }, { "sustain", 0.25f }, { "release", 0.12f }, { "glide", 0.05f },
                        { "chorus", 0.0f } } },

        { "Classic Lead", { { "saw", 1.0f }, { "pulse", 1.0f }, { "pw", 0.3f }, { "sub", 0.2f }, { "cutoff", 3200.0f },
                            { "res", 0.35f }, { "envAmt", 0.3f }, { "keyFollow", 1.0f }, { "attack", 0.005f },
                            { "decay", 0.5f }, { "sustain", 0.8f }, { "release", 0.2f }, { "glide", 0.12f },
                            { "lfoDco", 0.12f }, { "lfoDelay", 0.5f }, { "lfoRate", 5.5f }, { "chorus", 1.0f },
                            { "delayMix", 0.2f }, { "delayFb", 0.35f } } },

        { "Analog Pluck", { { "saw", 1.0f }, { "pulse", 1.0f }, { "pwMode", 2.0f }, { "pw", 0.6f }, { "cutoff", 600.0f },
                            { "res", 0.3f }, { "envAmt", 0.7f }, { "attack", 0.001f }, { "decay", 0.45f },
                            { "sustain", 0.0f }, { "release", 0.3f }, { "chorus", 1.0f }, { "revMix", 0.15f } } },

        { "Resonant Sweep", { { "saw", 1.0f }, { "pulse", 0.0f }, { "cutoff", 300.0f }, { "res", 0.75f },
                              { "envAmt", 0.8f }, { "attack", 0.9f }, { "decay", 2.5f }, { "sustain", 0.4f },
                              { "release", 1.0f }, { "lfoVcf", 0.15f }, { "lfoRate", 0.3f }, { "chorus", 2.0f } } },

        { "Arp Glass", { { "arpOn", 1.0f }, { "arpMode", 1.0f }, { "arpRange", 1.0f }, { "arpRate", 9.0f },
                         { "saw", 0.0f }, { "pulse", 1.0f }, { "pw", 0.4f }, { "pwMode", 1.0f }, { "cutoff", 3800.0f },
                         { "res", 0.3f }, { "envAmt", 0.4f }, { "attack", 0.002f }, { "decay", 0.3f },
                         { "sustain", 0.3f }, { "release", 0.35f }, { "chorus", 1.0f }, { "delayMix", 0.3f },
                         { "delayFb", 0.4f }, { "delaySync", 1.0f }, { "delayDiv", 8.0f }, { "revMix", 0.3f } } },

        { "Chord Stab", { { "chordOn", 1.0f }, { "chordType", 4.0f }, { "saw", 1.0f }, { "pulse", 1.0f }, { "pw", 0.5f },
                          { "cutoff", 2000.0f }, { "res", 0.15f }, { "envAmt", 0.4f }, { "attack", 0.005f },
                          { "decay", 0.6f }, { "sustain", 0.2f }, { "release", 0.35f }, { "chorus", 1.0f },
                          { "poly", 12.0f } } },

        { "Unison Saw", { { "unison", 3.0f }, { "detune", 0.5f }, { "saw", 1.0f }, { "pulse", 0.0f },
                          { "cutoff", 2600.0f }, { "res", 0.2f }, { "envAmt", 0.3f }, { "attack", 0.01f },
                          { "decay", 0.8f }, { "sustain", 0.7f }, { "release", 0.4f }, { "chorus", 1.0f },
                          { "poly", 8.0f } } },

        { "Vintage Organ", { { "saw", 0.0f }, { "pulse", 1.0f }, { "pw", 0.0f }, { "sub", 0.6f }, { "cutoff", 5000.0f },
                             { "res", 0.0f }, { "envAmt", 0.0f }, { "attack", 0.002f }, { "decay", 0.002f },
                             { "sustain", 1.0f }, { "release", 0.01f }, { "lfoDco", 0.04f }, { "lfoRate", 6.5f },
                             { "chorus", 3.0f } } },

        { "Noise Wind", { { "saw", 0.0f }, { "pulse", 0.0f }, { "noise", 0.8f }, { "cutoff", 1200.0f }, { "res", 0.55f },
                          { "envAmt", 0.5f }, { "attack", 1.5f }, { "decay", 2.0f }, { "sustain", 0.6f },
                          { "release", 2.0f }, { "lfoVcf", 0.3f }, { "lfoRate", 0.5f }, { "chorus", 2.0f },
                          { "revMix", 0.35f } } },

        { "Env2 Filter Pluck", { { "saw", 1.0f }, { "cutoff", 500.0f }, { "res", 0.35f }, { "envAmt", 0.0f },
                                 { "attack", 0.001f }, { "decay", 1.0f }, { "sustain", 0.8f }, { "release", 0.3f },
                                 { "env2D", 0.45f }, { "env2S", 0.0f }, { "env2Dest1", 3.0f }, { "env2Amt1", 0.7f },
                                 { "chorus", 1.0f } } },

        { "LFO2 Wobble", { { "saw", 1.0f }, { "cutoff", 900.0f }, { "res", 0.4f }, { "envAmt", 0.2f },
                           { "lfo2Rate", 4.0f }, { "lfo2Wave", 1.0f }, { "lfo2Dest1", 3.0f }, { "lfo2Amt1", 0.5f },
                           { "chorus", 1.0f } } },
    };
    return list;
}
}

//==============================================================================
juce::StringArray PresetManager::getFactoryNames() const
{
    juce::StringArray names;
    for (const auto& f : factoryPresets())
        names.add (f.name);
    return names;
}

juce::File PresetManager::getUserDir() const
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
               .getChildFile ("Sixty").getChildFile ("Presets");
}

juce::StringArray PresetManager::getUserNames() const
{
    juce::StringArray names;
    for (const auto& f : getUserDir().findChildFiles (juce::File::findFiles, false, "*.sixtypreset"))
        names.add (f.getFileNameWithoutExtension());
    names.sort (true);
    return names;
}

juce::String PresetManager::getCurrentName() const
{
    const auto n = apvts.state.getProperty ("presetName").toString();
    return n.isEmpty() ? juce::String ("Init") : n;
}

juce::String PresetManager::sanitize (const juce::String& name)
{
    return juce::File::createLegalFileName (name.trim()).trim().substring (0, 60);
}

void PresetManager::setName (const juce::String& name)
{
    apvts.state.setProperty ("presetName", name, nullptr);
}

void PresetManager::resetToDefaults()
{
    for (auto* par : apvts.processor.getParameters())
        if (auto* r = dynamic_cast<juce::RangedAudioParameter*> (par))
            r->setValueNotifyingHost (r->getDefaultValue());
}

void PresetManager::markClean()
{
    snapshot.clear();
    for (auto* par : apvts.processor.getParameters())
        snapshot.push_back (par->getValue());
}

bool PresetManager::isModified() const
{
    const auto& params = apvts.processor.getParameters();
    if ((int) snapshot.size() != params.size())
        return false;

    for (int i = 0; i < params.size(); ++i)
        if (std::abs (params[i]->getValue() - snapshot[(size_t) i]) > 1.0e-4f)
            return true;
    return false;
}

//==============================================================================
bool PresetManager::loadFactory (int index)
{
    const auto& list = factoryPresets();
    if (index < 0 || index >= (int) list.size())
        return false;

    resetToDefaults();
    for (const auto& [id, value] : list[(size_t) index].values)
        if (auto* par = apvts.getParameter (id))
            par->setValueNotifyingHost (par->convertTo0to1 (value));

    setName (list[(size_t) index].name);
    markClean();
    return true;
}

bool PresetManager::loadUser (const juce::String& name)
{
    const auto file = getUserDir().getChildFile (sanitize (name) + ".sixtypreset");
    if (! file.existsAsFile())
        return false;

    auto xml = juce::XmlDocument::parse (file);
    if (xml == nullptr || ! xml->hasTagName (apvts.state.getType()))
        return false;

    resetToDefaults();
    apvts.replaceState (juce::ValueTree::fromXml (*xml));
    setName (file.getFileNameWithoutExtension());
    markClean();
    return true;
}

bool PresetManager::saveUser (const juce::String& rawName)
{
    auto name = sanitize (rawName);
    if (name.isEmpty())
        return false;
    if (getFactoryNames().contains (name))
        name += " (user)";

    const auto dir = getUserDir();
    if (! dir.createDirectory().wasOk())
        return false;

    setName (name);
    auto xml = apvts.copyState().createXml();
    if (xml == nullptr)
        return false;

    const bool ok = xml->writeTo (dir.getChildFile (name + ".sixtypreset"));
    if (ok) markClean();
    return ok;
}

bool PresetManager::deleteUser (const juce::String& name)
{
    const auto file = getUserDir().getChildFile (sanitize (name) + ".sixtypreset");
    return file.existsAsFile() && file.deleteFile();
}

bool PresetManager::importFile (const juce::File& file)
{
    auto xml = juce::XmlDocument::parse (file);
    if (xml == nullptr || ! xml->hasTagName (apvts.state.getType()))
        return false;

    resetToDefaults();
    apvts.replaceState (juce::ValueTree::fromXml (*xml));
    const auto name = sanitize (file.getFileNameWithoutExtension());
    setName (name);
    markClean();
    return saveUser (name); // fica tambem na lista do utilizador
}

bool PresetManager::exportFile (const juce::File& file) const
{
    auto xml = apvts.copyState().createXml();
    return xml != nullptr && xml->writeTo (file);
}

bool PresetManager::step (int direction)
{
    const auto factory = getFactoryNames();
    const auto user = getUserNames();
    const int total = factory.size() + user.size();
    if (total == 0)
        return false;

    const auto cur = getCurrentName();
    int idx = factory.indexOf (cur);
    if (idx < 0)
    {
        const int u = user.indexOf (cur);
        if (u >= 0) idx = factory.size() + u;
    }

    idx = idx < 0 ? (direction > 0 ? 0 : total - 1) : (idx + direction + total) % total;
    return idx < factory.size() ? loadFactory (idx) : loadUser (user[idx - factory.size()]);
}
