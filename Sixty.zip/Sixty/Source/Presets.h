#pragma once
#include <juce_audio_utils/juce_audio_utils.h>

// Gestor de presets: presets de fabrica (em codigo) + presets do utilizador (ficheiros .sixtypreset).
// O nome do preset actual fica guardado no estado do plugin (propriedade "presetName").
class PresetManager
{
public:
    explicit PresetManager (juce::AudioProcessorValueTreeState& a) : apvts (a) {}

    juce::StringArray getFactoryNames() const;
    juce::StringArray getUserNames() const;
    juce::String getCurrentName() const;

    bool loadFactory (int index);
    bool loadUser (const juce::String& name);
    bool saveUser (const juce::String& name);
    bool deleteUser (const juce::String& name);
    bool importFile (const juce::File& file);
    bool exportFile (const juce::File& file) const;
    bool step (int direction);          // -1 anterior, +1 seguinte (fabrica e depois utilizador)

    bool isModified() const;            // algum parametro mudou desde o ultimo load/save
    void markClean();

    juce::File getUserDir() const;
    static juce::String sanitize (const juce::String& name);

private:
    void resetToDefaults();
    void setName (const juce::String& name);

    juce::AudioProcessorValueTreeState& apvts;
    std::vector<float> snapshot;
};
